////////////////////////////////////////////////////////////////////////
// A lightweight class representing an instance of an object that can
// be drawn onscreen.  An Object consists of a shape (batch of
// triangles), and various transformation, color and texture
// parameters.  It also contains a list of child objects to be drawn
// in a hierarchical fashion under the control of parent's
// transformations.
//
// Methods consist of a constructor, and a Draw procedure, and an
// append for building hierarchies of objects.

#include <cstdlib>

#include <glbinding/gl/gl.h>
#include <glbinding/Binding.h>
using namespace gl;

#define GLM_FORCE_CTOR_INIT
#define GLM_FORCE_RADIANS
#define GLM_SWIZZLE
#include <glm/glm.hpp>

#include "framework.h"
#include "shapes.h"
#include "transform.h"

#include <glu.h>                // For gluErrorString
#define CHECKERROR {GLenum err = glGetError(); if (err != GL_NO_ERROR) { fprintf(stderr, "OpenGL error (at line object.cpp:%d): %s\n", __LINE__, gluErrorString(err)); exit(-1);} }


Object::Object(Shape* _shape, const int _objectId,
    const glm::vec3 _d, const glm::vec3 _s, const float _n, const bool _isReflective,
    Texture* texture, Texture* normalMap)
	: shape(_shape), objectId(_objectId), drawMe(true), diffuseColor(_d),
	  specularColor(_s), shininess(_n),
	  isReflective(_isReflective), skyboxReflectionStrength(0), texture(texture), normalMap(normalMap)
{
}


void Object::Draw(ShaderProgram* program, glm::mat4& objectTr, bool renderReflective)
{
    CHECKERROR
    // @@ The object specific parameters (uniform variables) used by
    // the shader are set here.  Scene specific parameters are set in
    // the DrawScene procedure in scene.cpp

    // @@ Textures, being uniform sampler2d variables in the shader,
    // are also set here.  Call texture->Bind in texture.cpp to do so.

    // Inform the shader of the surface values Kd, Ks, and alpha.
    int loc = glGetUniformLocation(program->programId, "diffuse");
    glUniform3fv(loc, 1, &diffuseColor[0]);

    loc = glGetUniformLocation(program->programId, "specular");
    glUniform3fv(loc, 1, &specularColor[0]);

    loc = glGetUniformLocation(program->programId, "shininess");
    glUniform1f(loc, shininess);

    loc = glGetUniformLocation(program->programId, "isReflective");
    glUniform1f(loc, isReflective);

    loc = glGetUniformLocation(program->programId, "skyboxReflectionStrength");
    glUniform1f(loc, skyboxReflectionStrength);

    // Inform the shader of which object is being drawn so it can make
    // object specific decisions.
    loc = glGetUniformLocation(program->programId, "objectId");
    glUniform1i(loc, objectId);

    // Inform the shader of this object's model transformation.  The
    // inverse of the model transformation, needed for transforming
    // normals, is calculated and passed to the shader here.
    loc = glGetUniformLocation(program->programId, "ModelTr");
    glUniformMatrix4fv(loc, 1, GL_FALSE, Pntr(objectTr));

    glm::mat4 inv = glm::inverse(objectTr);
    loc = glGetUniformLocation(program->programId, "NormalTr");
    glUniformMatrix4fv(loc, 1, GL_FALSE, Pntr(inv));

    // If this object has an associated texture, this is the place to
    // load the texture into a texture-unit of your choice and inform
    // the shader program of the texture-unit number.  See
    // Texture::Bind for the 4 lines of code to do exactly that.

    glUniform1i(glGetUniformLocation(program->programId, "useTex"), texture != nullptr);
    glUniform1i(glGetUniformLocation(program->programId, "useNormal"), normalMap != nullptr);

    if (texture != nullptr)
        texture->BindTexture(0, program->programId, "tex");
    if (normalMap != nullptr)
        normalMap->BindTexture(1, program->programId, "normalMap");

    const bool drawObject = drawMe && (!isReflective || (isReflective && renderReflective));

    // Draw this object
    CHECKERROR
    if (shape)
        if (drawObject)
            shape->DrawVAO();
    CHECKERROR

    if (texture != nullptr)
        texture->UnbindTexture(0);
    if (normalMap != nullptr)
        normalMap->UnbindTexture(1);

    CHECKERROR
    // Recursively draw each sub-objects, each with its own transformation.
    if (drawObject)
        for (auto& instance : instances)
        {
            CHECKERROR
            glm::mat4 itr = objectTr * instance.second * animTr;
            CHECKERROR
            instance.first->Draw(program, itr, renderReflective);
            CHECKERROR
        }

    CHECKERROR
}
